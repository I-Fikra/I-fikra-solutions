import {
  ChangeDetectionStrategy,
  Component,
  inject,
  output,
  signal,
  ViewEncapsulation,
} from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';

import { UIStyleDesignerComponent } from './ui-style-designer.component';
import { UIStyleDesignerService } from './ui-style-designer.service';

@Component({
  selector: 'app-ui-style-section',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  imports: [ButtonModule, ToastModule, UIStyleDesignerComponent],
  providers: [MessageService],
  templateUrl: './ui-style-section.component.html',
  styleUrl: './ui-style-section.component.scss',
})
export class UIStyleSectionComponent {
  private readonly svc = inject(UIStyleDesignerService);
  private readonly messageService = inject(MessageService);

  readonly done = output<void>();

  readonly showAdvanced = signal(false);

  openAdvanced(): void {
    this.showAdvanced.set(true);
  }

  closeAdvanced(): void {
    this.showAdvanced.set(false);
  }

  saveDefault(): void {
    // Keep current (default) styles as-is and emit done
    this.messageService.add({
      severity: 'success',
      summary: 'UI Style Saved',
      detail: 'Default website style applied.',
      life: 2000,
    });
    setTimeout(() => this.done.emit(), 600);
  }
}
